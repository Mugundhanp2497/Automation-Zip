package org.alphind.alphamcs.pages;

import org.alphind.alphamcs.base.CommonFunctions;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ServiceMatrixPage extends CommonFunctions 

{
	WebDriver driver;
	static String patientLastName;
	static String patientFirstName;


	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	
	@FindBy(xpath="//span[text()='Master']")
	WebElement Master;
	
	@FindBy(xpath="//a[text()=' Service Maintenance ']")
	WebElement SeviceMaintenance;
	
	@FindBy(xpath="//a[text()='Service Matrix']")
	WebElement ServiceMatrix;
	
	
	
	
	
	

}
