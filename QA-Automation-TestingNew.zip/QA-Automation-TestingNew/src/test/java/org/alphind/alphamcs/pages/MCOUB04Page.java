package org.alphind.alphamcs.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.alphind.alphamcs.base.CommonFunctions;
import org.apache.poi.hpsf.Date;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.codoid.products.fillo.Select;

public class MCOUB04Page extends CommonFunctions {

	WebDriver driver;
	static String patientLastName;
	static String patientFirstName;


	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	//private static final Logger log = LogManager.getLogger(MCOUB04Page.class);

	@FindBy(xpath = "//span[text()='Create ']")
	WebElement createButton;
	
	@FindBy(xpath="//span[text()=' Provider Search ']")
	WebElement providerSearchBtn;

	@FindBy(xpath="//mat-label[text()='Provider ID']/parent::label/ancestor::span/preceding-sibling::input")
	WebElement serchPrvID;
	
	@FindBy(xpath="//span[text()='Search']")
	WebElement prvSearch;
	
	@FindBy(xpath="(//div/table/tbody)[9]/tr")
	WebElement selectfirstPrv;
	
	@FindBy(xpath="//span[contains(text(),'Select Provider')]/parent::button")
	WebElement selectProvider;
	
	@FindBy(xpath="//mat-select[@id='mat-select-2']")
	WebElement clickSitedrop;
	
	@FindBy(xpath="//span[text()=' 2589 - TERMED- No Bounds Care, Inc. ']")
	WebElement selectSite;
	
	@FindBy(xpath="//span[@class='ml-1 text-gray']")
	WebElement claimnum;
	
	@FindBy(xpath="//input[@ng-reflect-name='Bill_type_04']")
	WebElement billType;
	
	@FindBy(xpath="//input[@formcontrolname='Stmt_prd_frm_06']")
	WebElement fromDate;
	
	@FindBy(xpath="//input[@formcontrolname='Stmt_prd_to_06']")
	WebElement toDate;
	
	@FindBy(xpath="//span[text()='Search ']")
	WebElement searchPatient;
    
	@FindBy(xpath="//mat-label[text()='Patient ID']/parent::label/ancestor::span/preceding-sibling::input")
	WebElement searchPatientId;
	
	@FindBy(xpath="//span[text()='Search']")
	WebElement searchpat;
	
	@FindBy(xpath="(//div/table/tbody)[9]/tr")
	WebElement selectFirstPat;
	
	@FindBy(xpath="//span[text()='Select Patient']")
	WebElement selectPatientbtn;
	
	@FindBy(xpath="//span[text()='Select Patient']")
	WebElement selectPatient;
	
	@FindBy(xpath="//input[@formcontrolname='Admsn_dt_12']")
	WebElement signDate;
	
	@FindBy(xpath="//span[text()=' Add ']")
	WebElement addServcie;
	
	@FindBy(xpath="//input[@formcontrolname='Rev_cd']")
	WebElement revCode;
	
	@FindBy(xpath="//input[@formcontrolname='Units']")
	WebElement units;
	
	@FindBy(xpath="//input[@formcontrolname='Charge']")
	WebElement charges;
	
	@FindBy(xpath="//input[@formcontrolname='Noncoveredcharge']")
	WebElement noncovercharge;
	
	@FindBy(xpath="(//span[text()=' Save ']/parent::button)[2]")
	WebElement saveService;
	
	@FindBy(xpath="//input[@formcontrolname='Charge']")
	WebElement toatlcharge;
	
	@FindBy(xpath="//div[@role='listbox']/child::mat-option[2]")
	WebElement billingNPI;
	
	@FindBy(xpath="//mat-select[@formcontrolname='Bill_prv_npi_56']")
	WebElement billingNPIclick;
	
	@FindBy(xpath="//input[@formcontrolname='Prin_diag_cd_67']")
	WebElement prinvipalDX;
	
	@FindBy(xpath="//input[@formcontrolname='Attnd_phy_npi_76']")
	WebElement AttendingNPI;
	
	@FindBy(xpath="//input[@formcontrolname='Cc_81a']")
	WebElement taxonamy;
	
	@FindBy(xpath="//span[text()=' Submit ']")
	WebElement submitbtn;
	
	@FindBy(xpath="//mat-select[@formcontrolname='Admsn_hr_13']")
	WebElement hr;
	
	@FindBy(xpath="//span[text()=' 01 ']")
	WebElement hr01;
	
	@FindBy(xpath="//mat-select[@formcontrolname='Priority_of_visit_type_14']")
	WebElement type;
	
	@FindBy(xpath="//span[text()=' 1 ']")
	WebElement type1;
	@FindBy(xpath="//mat-select[@formcontrolname='Ref_src_15']")
	WebElement Src;
	// patient Search elements

	////////////////// Implementations

	public MCOUB04Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String createUB04Claim( ) throws IOException {
		String claimId="";
		
		//DateFormat dform = new SimpleDateFormat( "MM/dd/yyyy" );
		//Date d= new Date();

		//System.out.print(dform.format(d));
		//waitUntilClickable(createButton, 30);
		waitForLoadingToDisappear();
		
		String path=".\\testData\\AlphaPlusTestData.xlsx";
    	FileInputStream ExcelFile = new FileInputStream(path);

		ExcelWBook = new XSSFWorkbook(ExcelFile);
		ExcelWSheet = ExcelWBook.getSheet("ub04");

		int numOfColumns = ExcelWSheet.getRow(1).getPhysicalNumberOfCells();
		int numOfRows = ExcelWSheet.getPhysicalNumberOfRows();
    	
		System.out.println(numOfColumns);
		System.out.println(numOfRows);
		
		for(int i=1;i<numOfRows;i++)
		{
			String patientid = ExcelWSheet.getRow(i).getCell(0).getStringCellValue();
	    	
			String patientSigndate = ExcelWSheet.getRow(i).getCell(1).getStringCellValue(); 

			String diagnosisCode =ExcelWSheet.getRow(i).getCell(2).getStringCellValue();

			String providerID = ExcelWSheet.getRow(i).getCell(3).getStringCellValue(); 
			
			String serviceFromDate = ExcelWSheet.getRow(i).getCell(4).getStringCellValue(); 
			
			String serviceToDate = ExcelWSheet.getRow(i).getCell(5).getStringCellValue();  
			
			String procCode = ExcelWSheet.getRow(i).getCell(6).getStringCellValue(); 
			
			

			String serviceAmt = ExcelWSheet.getRow(i).getCell(7).getStringCellValue();
			

			String NCcharge = ExcelWSheet.getRow(i).getCell(8).getStringCellValue();
			
			String daysUnits = ExcelWSheet.getRow(i).getCell(9).getStringCellValue(); 

			String diagnosispointer = ExcelWSheet.getRow(i).getCell(10).getStringCellValue();
			
			String attendingNPI = ExcelWSheet.getRow(i).getCell(11).getStringCellValue();
			

			String renderingtaxonomyCode = ExcelWSheet.getRow(i).getCell(12).getStringCellValue(); 
			
			String billtype = ExcelWSheet.getRow(i).getCell(13).getStringCellValue(); 

			
            
			
		putStaticWait(2);
		click(createButton, "Create button");
		putStaticWait(2);
		click(providerSearchBtn,"Provider search button ");
		putStaticWait(5);
		sendKeys(serchPrvID,"Provider Id",providerID);
		putStaticWait(2);
		click(prvSearch,"Provider search");
		putStaticWait(2);
		click(selectfirstPrv,"Select First Provider");
		putStaticWait(2);
		click(selectProvider,"Select Provider");
		putStaticWait(8);
		click(clickSitedrop,"expand site dropdown");
		putStaticWait(2);
		click(selectSite,"Select Site");
		putStaticWait(2);
		System.out.println(getText(claimnum));
		sendKeys(billType,"Bill Type",billtype);
		
		sendKeys(fromDate,"From Datw",serviceFromDate);
		sendKeys(toDate,"To Date",serviceToDate);
		click(searchPatient,"Search Patient button");
		putStaticWait(2);
		sendKeys(searchPatientId,"Enter paient ID",patientid);
		putStaticWait(2);
		click(searchpat,"search Patient");
		putStaticWait(2);
		click(selectFirstPat,"select First Pat");
		putStaticWait(2);
		click(selectPatient,"Select Patient");
		putStaticWait(2);
		sendKeys(signDate,"sign Date",patientSigndate);
		putStaticWait(2);
		click(hr,"Hr");
		click(hr01,"Hr 01");
		click(type,"Type");
		click(type1,"type 1");
		click(Src,"Src");
		click(type1,"type 1");
		click(addServcie,"add Servcie");
		putStaticWait(2);
		sendKeys(revCode,"rev Code",procCode);
		putStaticWait(2);
		sendKeys(toatlcharge,"toatlcharge",serviceAmt);
		putStaticWait(2);
		sendKeys(units,"units",daysUnits);
		putStaticWait(2);
		sendKeys(noncovercharge,"non covered charge",NCcharge);
		putStaticWait(2);
		click(saveService,"save Service");
		putStaticWait(2);
		click(billingNPIclick,"billingNPIclick");
		click(billingNPI,"billin NPI");
		sendKeys(prinvipalDX,"prinvipal DX",diagnosisCode);	
		sendKeys(AttendingNPI,"Attending NPI",attendingNPI);
		sendKeys(taxonamy,"taxonamy",renderingtaxonomyCode);
		waitForLoadingToDisappear();
		putStaticWait(2);
		click(submitbtn,"submit btn");
		putStaticWait(2);

		return claimId;
	}
		return "0";
	}

}
