package org.alphind.alphamcs.pages;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ClmDuplicateTest {
    public static void main(String[] args) {
        try {
            String filePath = "path/to/your/textfile.txt";
            String outputPath = "path/to/output/ClmDuplicate.xlsx";

            XSSFWorkbook excelWorkbook = new XSSFWorkbook();
            XSSFSheet excelSheet = excelWorkbook.createSheet("ClmDuplicate");

            Pattern pattern = Pattern.compile("ALH\\d{13}");
            int rowNum = 0;

            try (BufferedReader reader = new BufferedReader(new FileReader(filePath)) {
                String line;

                while ((line = reader.readLine()) != null) {
                    Matcher matcher = pattern.matcher(line);

                    while (matcher.find()) {
                        String match = matcher.group();
                        String number = match.substring(8);

                        excelSheet.createRow(rowNum++).createCell(0).setCellValue(number);
                    }
                }
            }

            try (FileOutputStream outputStream = new FileOutputStream(outputPath)) {
                excelWorkbook.write(outputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
