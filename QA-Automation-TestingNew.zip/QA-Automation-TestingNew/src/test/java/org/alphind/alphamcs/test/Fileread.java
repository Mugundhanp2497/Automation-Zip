package org.alphind.alphamcs.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Fileread   {
	static double TotalclAmt;
	static double LineAmt;

	static double M=0;
	 static double TotalOutOfBalanceIssue=0;
    public static void main(String[] args) throws NumberFormatException {
    	
    	
        // Specify the path to the text file you want to read
        String filePath = "C:\\Users\\Alphi-Spare\\Documents\\Sound recordings\\AL_SHC_MCD_P_OutGoing_837_062965_20231011_1.txt";
        File file = new File(filePath);

        boolean startProcessing = false;

        int a=1;
       
        try (BufferedReader br = new BufferedReader(new FileReader(filePath)))
        {
            String line;
                for(int i=1;i<99000;i=i+2)
                {
            // Read each line from the file
            while ((line = br.readLine()) != null) 
            {
                // Check if the line contains "* "
            	
                if (line.contains("CLM*ALH")) {
                	System.out.println(line);
                	a++;
               	 //System.out.println(line);
               	 
               	 String[] b=line.split("\\*");
               	 
               	String TotalClaimAmount=b[2];
               	
               	 TotalclAmt= Double.parseDouble(TotalClaimAmount);
               	 
               	System.out.println("Total Amount "+TotalclAmt);
                    continue; // Skip this line and start processing from the next line
                }
                
                if(line.contains("SV1"))
                {
                	String[] c=line.split("\\*");
                  	String LineAmounts=c[2];
                  	
                	 LineAmt= Double.parseDouble(LineAmounts);
                	
                	System.out.println(LineAmt);
                	M=LineAmt+M;
                }

                // Check if we have started processing and if the line contains "HL "
                if (line.startsWith("HL*"+i+"*")) {
                	System.out.println("Total Line Amount  "+M);
                	if(M==TotalclAmt)
                	{
                		System.out.println("Total amount is equal to line amount");
                	}
                	else
                	{
                		System.out.println("Not equal");
                		TotalOutOfBalanceIssue++;
                	}
                	
                    System.out.println("Found 'HL ': " + line);
                    M=0;
                    break; // Exit the loop when "HL " is found
                }
                
                // If we have started processing, perform your desired actions here
                if (startProcessing) {
                    System.out.println("Processing line: " + line);
                }
            
        
        // Create a File object representing the text file
        
   
                
               // System.out.println(line);
            
            
            // Close the scanner when done
            }

    }
                System.out.print("Total out of balance issue  ="+TotalOutOfBalanceIssue);        
        }
    
    catch (IOException e) 
    {
            e.printStackTrace();
        }
    }
    }


