package org.alphind.alphamcs.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ClmDublicateTest 

{
	static String number;
	static String str;
	static double ClmHdr;
static double LineAmt;
static String[] clm;
static double M=0;
 static double TotalOutOfBalanceIssue=0;
 static int i=1;

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
public static void main(String[] args) throws NumberFormatException, IOException 
{
	
	
    // Specify the path to the text file you want to read
    String filePath = "C:\\Users\\Alphi-Spare\\Documents\\Sound recordings\\AL_SHC_MCD_P_OutGoing_837_062965_20231011_1.txt";
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath)))
    {
        String line;

       
        // Define a regular expression pattern to match "ALH" followed by any 5 digits
        Pattern pattern = Pattern.compile("ALH\\d{13}");
      int m=0;
        while ((line = reader.readLine()) != null) {
            Matcher matcher = pattern.matcher(line);

            while (matcher.find()) {
                // Extract the matched text and remove "ALH"
                String match = matcher.group();
                String number = match.substring(8); // Skip the "ALH"
                
                //System.out.println("Found number after ALH: " + number);
               
                String path="C:\\Users\\Alphi-Spare\\Documents\\DulpicateClm.Xlsx";
            	File f=new File(path);
                FileInputStream fin=new FileInputStream(path);
        		ExcelWBook = new XSSFWorkbook(fin);
        		ExcelWSheet = ExcelWBook.getSheet("ClmDuplicate");
        		
        		ExcelWSheet.createRow(m++).createCell(0).setCellValue(number); 
        		FileOutputStream outputStream = new FileOutputStream(f);
                ExcelWBook.write(outputStream);
                          
            }
            
            
           
    }
            }
    
catch (IOException e) 
{
        e.printStackTrace();
    }
    
    
    String path="C:\\Users\\Alphi-Spare\\Documents\\DulpicateClm.Xlsx";
	File f=new File(path);
    FileInputStream fin=new FileInputStream(path);
	ExcelWBook = new XSSFWorkbook(fin);
	ExcelWSheet = ExcelWBook.getSheet("ClmDuplicate");  
	
	int rn = ExcelWSheet.getPhysicalNumberOfRows();
	
	for(int a=0;a<rn;a++)
	{
	
		for(int b=a+1;b<rn;b++)
		{
			String n1= ExcelWSheet.getRow(a).getCell(0).getStringCellValue();
			String n2= ExcelWSheet.getRow(b).getCell(0).getStringCellValue();
			
			if(n1.equals(n2))
					{
				System.out.println("Duplicate CLM "+n1);
				
					}
		}
	}
    
}
}
